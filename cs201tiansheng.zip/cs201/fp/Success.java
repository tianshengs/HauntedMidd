// Success.java
// Final Project CS201
// Aiko Hassett (Section A), Tiansheng Sun (Section B)



/*
 ------------------------------------------------------------------------------
 Shows the successful ending.
 ------------------------------------------------------------------------------
*/

class Success extends Result{
	private static final long serialVersionUID = 1L;
	Result successResult;
	
	public Success() {
		super();
	}
	
	// set the text for the ending
	public void setcongratulations(int lives) {
		news.setText("<html>Congratulations! <br> "
    			+ "You survived the Haunted Midd! <br> Your friends are so proud of you!"
    			+ " <br> <br> You won with " + lives + " lives left.");
	}
}