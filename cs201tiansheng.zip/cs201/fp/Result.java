// Result.java
// Final Project CS201
// Aiko Hassett (Section A), Tiansheng Sun (Section B)

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import javax.swing.*;

/*
 ------------------------------------------------------------------------------
 A super class that shows the ending when the game ends. 
 ------------------------------------------------------------------------------
 Use a super class for both the Success and Failure Panels.
 https://www.java-forums.org/new-java/52271-using-cardlayout-java-applet-.html
 ------------------------------------------------------------------------------
*/

class Result extends Main{
	private static final long serialVersionUID = 1L;
	
	int finalQuestions;
	int finalLives;
	JLabel finalScenarios;
	JLabel news;
	JButton restart; 
	
	public Result() {
		drawFinalScenario();
		drawNews();
	}
	
	// sets the final scenario
	public void drawFinalScenario(){
		
		finalScenarios = new JLabel();
		finalScenarios.setFont(new Font("TimesRoman", Font.BOLD, 30)); // set text
    	finalScenarios.setOpaque(true);
    	finalScenarios.setBackground(Color.magenta);
    	finalScenarios.setHorizontalAlignment(JLabel.LEFT);
	}
	// sets up format for news 
	public void drawNews(){
		
		news = new JLabel();
    	news.setFont(new Font("Serif", Font.BOLD, 35)); // set text
        news.setVerticalAlignment(JLabel.CENTER);
        news.setHorizontalAlignment(JLabel.CENTER);
        news.setOpaque(true); 
        news.setForeground(Color.red);
        news.setBackground(Color.yellow);

        restart = new JButton("restart");
        restart.setBackground(Color.red);
        
        setLayout(new BorderLayout());
        add("North", finalScenarios);
        add("Center", news);
        add("South", restart); 
    }
	public void addNextActionListener(ActionListener listener) {
        restart.addActionListener(listener);
    }	 
}