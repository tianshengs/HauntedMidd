// Failure.java
// Final Project CS201
// Aiko Hassett (Section A), Tiansheng Sun (Section B)



/*
 ------------------------------------------------------------------------------
 Shows the unsuccessful ending.
 ------------------------------------------------------------------------------
 */

class Failure extends Result{
	private static final long serialVersionUID = 1L;
	
	public Failure() {
		super();
	}
    
	//set the text for the ending
	public void setbadnews(int question) {
		news.setText("<html>Unfortunately, everyone died! <br> "
    			+ "You did not survived the Haunted Midd! <br>"
    			+ " <br> <br> You only finished " + finalQuestions + " questions.<html>");	
	}
}