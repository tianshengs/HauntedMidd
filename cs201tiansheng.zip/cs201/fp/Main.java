// Main.java
// Final Project CS201
// Aiko Hassett (Section A), Tiansheng Sun (Section B)


/*
 ------------------------------------------------------------------------------
 Shows the main screen of the game, where the questions are presented. 
 ------------------------------------------------------------------------------
 Reference to setting opaque to setBackground work:
 //https://stackoverflow.com/questions/2380314/how-do-i-set-a-jlabels-background-color
 ------------------------------------------------------------------------------
*/

import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.*;

class Main extends JPanel implements MouseListener{
	
	private static final long serialVersionUID = 1L; // to avoid Eclipse warning
	
    protected int livesLeft; // keep track of the number of lives a user still have
	protected int questionNumber; //keep track of the question Number
	protected int livesLost; // keep track of the number of lives a user lost
	protected int optionIndex;
	
	protected JLabel title; // the title label 
	protected JLabel questionText; // a label presenting a question
	protected JLabel scenarios; // a label that print out the scenario
	protected JLabel numberOfLives; // a label that shows the number of lives  
	protected JLabel questionNumberLabel; // the question number label that appears above question text
	
	protected JButton optionA; 
	protected JButton optionB;
	protected JButton optionC;
	
	protected boolean action;
	
	protected String [] Qarr ;
	protected String[][] optionArr;
	
	public Main(){
		questionText = new JLabel();
		optionA = new JButton();
		optionB = new JButton();
		optionC = new JButton();
		setScenarios();
		setNumberOfLives();
		setquestionNumberLabel();
		reset();
		titlePanel();
		
		
		// main panel
        setLayout(new BorderLayout());
        add("North", titlePanel());
        add("Center", createMainPanel());
	}
	
	// resets the game and the variables associated 
    public void reset() {
    	livesLeft = 5;
    	questionNumber = 1;
		numberOfLives.setText(" " + livesLeft + " lives left...");
		questionNumberLabel.setText("Question " + questionNumber);
		scenarios.setText("<html>Welcome!<html>");
		createQuestion();
		createOption();

    }

    // creates questions 
    public void createQuestion() {
    						
    	Qarr = new String[] {"<html>The dining hall is closed. You're hungry. "
    			             + "Where would you like to go?<html>", // question 1
    			             
    			             "<html>After the dinner, you want to have some fun. "
					  		 + "Where would you like to go?<html>", // question 2
					  		 
					  		 "<html>It's night time, you have to find a place to sleep. "
					  		 + "What do you want to do?<html>", // question 3
					  		 
					  		 "<html>Suddenly you hear a voice asking you to go to the restroom. "
					  		 + "What do you want to do?<html>", // question 4
					  		 
					  		 "<html>You realized this place is dangerous. "
					  		 + "You have to figure out a way to leave the haunted house. "
					  		 + "How do you get out of the house?<html>"}; // question 5
    	
    	setQuestionText();
   
    }
    
    // creates options
    public void createOption() {
    	
    	optionArr = new String[][] {{"<html>Go to the dining hall anyway<html>", 
    								"<html>Go to Sabai Sabai<html>", 
    								"<html>Go to your host family's house<html>"}, 

    								{"<html>Fitness Center<html>",
    								"<html>Burlington<html>", 
    								"<html>Haunted House<html>"}, 
								
    								{"<html>Go back to your room. <html>", 
    								"<html>Stay at Middlebury Inn. <html>",	 
    								"<html>Go to Jewett (Health and Wellness house that nobody knows about). <html>",
    								}, 
	
    								{"<html>Stay in your bed<html>", 
    								"<html>Go to the restroom<html>",	 
    								"<html>Follow the voice<html>",
    								}, 
	
    								{"<html>Go out the front door. <html>", 
    								"<html>Climb to the roof and use the emergency ladder. <html>",	 
    								"<html>You called your friend asked your friend to come pick you up. <html>",
    								}};
    								
    	setOption();
    	
    }
    
    // creates scenario
    public String[][] createScenario() {

    	String[] [] arr = { 
    	    
    		// panel 1

            //good scenarios
			{"<html>You got lucky because today is Thanksgiving! The dining hall has "
			 + "a special meal ready for you.<html>", 
			 
			 "<html>Sabai Sabai is open! You ask for hotpot, but the owner gives you "
			 + "noodle soup instead, but overall you get a good meal.<html>", 
			 
			 "<html>Your host family cooks great food! You had some delicious tofurkey.<html>"}, 
			
			//bad scenarios
			{"<html>The dining hall is CLOSED. You can't get any food there! You lost " + livesLost + " lives.<html>", 

			 "<html>You lose your ID card on the way home! You can't get back to your dorm, "
			 + "so you freeze to death. You lost " + livesLost + " lives.<html>", 
			 
			 "<html>Your host family's vicious dog bites you. You lost " + livesLost + " lives.<html>"}, 
			
			// panel 2
			
			//good scenarios
			{"<html>Everyone exercises and become super muscular.<html>", 
				 
			 "<html>Good thing today's Black Friday! You got all the best deals! <html>", 
			 
			 "<html>The Haunted House wasn't that scary, but you had a great time. <html>"}, 
			
			//bad scenarios
			{"<html>You try to deadlift, and break your spine. You lost " + livesLost + " lives.<html>",
				 
			 "<html>You lost all your money, your passport, and missed the bus back to campus. You lost " + livesLost + " lives.<html>", 
			 
			 "<html>You got so scared that you had a heart attack. You lost " + livesLost + " lives.<html>"}, 
			
			// panel 3
			
			//good scenarios
			{"<html>Turns out your room is haunted! But you are familiar with your room. "
			 + "You hit the ghost in the head with your desk lamp. <html>", 
			 
			 "<html>Turns out Middlebury Inn is haunted! "
			 + "But the hotel manager gave you a room that didn't have ghosts in it. <html>", 
			 
			 "<html>OH NO, JEWETT IS HAUNTED! But you realize that your friend lives in Jewett. "
			 + "The friend shares their bed with you for the night. <html>"}, 
			
			//bad scenarios
			{"<html>...but your room is haunted! And you saw two ghosts kissing each other! "
			 + "You died because of a heart condition due to singleness. "
			 + "You lost " + livesLost + " lives.<html>", 
			 
			 "<html>Turns out Middlebury Inn is a 200-year-old building that is haunted during thanksgiving break. "
			 + "Your room had too many ghosts in it, and one of them turned you into a zombie."
			 + " You lost " + livesLost + " lives.<html>", 
			 
			 "<html>This house is haunted! It was a snowy day, and the ghost pushed you down stairs, "
			 + "resulting in a spine injury and death. You lost " + livesLost + " lives.<html>"}, 
			
			// panel 4
			
			//good scenarios
			{"<html>You fall asleep and the voice disappears. Nothing happens. <html>", 
				 
			 "<html>You found 100 million dollars.<html>", 
			 
			 "<html>You shouted at the voice and the voice ran away.<html>"}, 
			
			//bad scenarios
			{"<html>The voice got angry that you didn't go to the restroom. "
			 + "The ghost kills you. You lost " + livesLost + " lives.<html>", 
			 
			 "<html>You shouldn't have listened to the voice! The ghost kills you by drowning you in the toilet. "
			 + "You lost " + livesLost + " lives.<html>", 
			 
			 "<html>You were so focused about finding the voice, that you did not pay attention to your surroundings. "
			 + "You fall off the window and die. You lost " + livesLost + " lives.<html>"}, 
			
			// panel 5
			
			//good scenarios
			{"<html>Somehow you didn't encounter any ghosts on your way to the front door, and you escaped the building. <html>", 
				 
			 "<html>You get out of the building fine. Nothing happens. <html>",
			 
			 "<html>Your friend comes to the rescue, and all the ghosts run away.<html>"}, 
			
			//bad scenarios
			{"<html>The ghost blocked the entrance. You can't get out. You lost " + livesLost + " lives.<html>", 
				 
			 "<html>You were out of shape, and took you too much time to climb the roof, and the ghost caught "
			 + "up to you. You lost " + livesLost + " lives.<html>", 
			 
			 "<html>You try to call your friend many times, but then you remember that your friend never responds "
			 + "to your messages anyway. The ghost finds you and you die. You lost " + livesLost + " lives.<html>"}};
	 
    	return arr;
    }	
	
	// draw the title panel 
    public JLabel titlePanel() {
    	title = new JLabel("Haunted Midd: The Survival XVII");
    	title.setFont(new Font("TimesRoman", Font.ITALIC|Font.BOLD, 20)); // set text
    	title.setHorizontalAlignment(JLabel.CENTER);
    	title.setForeground(Color.black);
    	title.setBackground(Color.darkGray);
		return title;
    }
    
    // sets question number label
    public void setNumberOfLives() {
    	
    	numberOfLives = new JLabel("  " + livesLeft + " lives left...");   
        numberOfLives = new JLabel("  " + livesLeft + " lives left...");   	
        numberOfLives.setFont(new Font("TimesRoman", Font.BOLD, 25)); // set text
        numberOfLives.setOpaque(true); 
        numberOfLives.setBackground(Color.cyan);
    }
    
    // sets scenario
    public void setScenarios() {
    	
    	scenarios = new JLabel("<html> Welcome! <html>");
    	scenarios.setFont(new Font("TimesRoman", Font.BOLD, 20)); // set text
    	scenarios.setOpaque(true);
    	scenarios.setBackground(Color.lightGray);
    	scenarios.setHorizontalAlignment(JLabel.CENTER);
    }
    
    // sets question number label 
    public void setquestionNumberLabel() {
    	
    	questionNumberLabel = new JLabel("Question" + questionNumber);
    	questionNumberLabel.setFont(new Font("TimesRoman", Font.ITALIC|Font.BOLD, 25)); // set text
    	questionNumberLabel.setOpaque(true);
    	questionNumberLabel.setForeground(Color.white);
    	questionNumberLabel.setBackground(Color.black);
    	questionNumberLabel.setHorizontalAlignment(JLabel.CENTER);	
    }
    
    // sets question number label 
    public void setQuestionText() {
    	
    	Border border = BorderFactory.createMatteBorder(40, 40, 40, 40, Color.gray);
    	
    	questionText.setText(Qarr[0]); // initialize variables
    	questionText.setBackground(Color.white);
    	questionText.setHorizontalAlignment(JLabel.CENTER);
    	questionText.setBorder(border);
    }
    
    // sets the option button 
    public void setOption() {
    	
    	optionA.setText(optionArr[questionNumber-1][0]);
    	optionB.setText(optionArr[questionNumber-1][1]); 
    	optionC.setText(optionArr[questionNumber-1][2]); 
	
    	optionA.setBackground(Color.black);
    	optionB.setBackground(Color.black);
    	optionC.setBackground(Color.black);

    	optionA.addMouseListener(this);	
    	optionB.addMouseListener(this);
    	optionC.addMouseListener(this);
    }
    
    // draws panels
    public JPanel drawScenarioLivesPanel() {
    	
    	// scenario, lives, question number panel
    	JPanel scenarioLivesPanel = new JPanel();
    	scenarioLivesPanel.setLayout(new BorderLayout());
    	
    	setNumberOfLives();
    	setScenarios();
    	setquestionNumberLabel();
    	
    	scenarioLivesPanel.add("Center", scenarios);
        scenarioLivesPanel.add("East", numberOfLives);
        scenarioLivesPanel.add("South", questionNumberLabel);
        
        return scenarioLivesPanel;
    }
    
    public JPanel drawOptionPanel(){
    	 // option panel
        JPanel optionPanel = new JPanel(); 
        optionPanel.setLayout(new GridLayout(3, 1)); // grid layout
        
        optionPanel.setFont(new Font("TimesRoman", Font.BOLD, 20)); // set text
    	
	    optionPanel.add(optionA);
	    optionPanel.add(optionB);
	    optionPanel.add(optionC);
	    
	    return optionPanel;    
    }
    
    public JPanel createMainPanel(){
    	// intermediate "center" panel w/ question and options
    	JPanel center = new JPanel(); 
    	center.setLayout(new GridLayout(3, 1));
    	
    	center.add(drawScenarioLivesPanel());
    	center.add(questionText);
        center.add(drawOptionPanel());
        return center;
    }
    
    // deals with mouse clicks
	public void mouseEntered(MouseEvent b) {
		
		((JButton) b.getSource()).setForeground(Color.white);
	}

	public void mouseExited(MouseEvent b) {
		
		((JButton) b.getSource()).setForeground(Color.darkGray);
	}	
	@Override
	public void mouseClicked(MouseEvent e) {
	}
	@Override
	public void mousePressed(MouseEvent e) {
	}
	@Override
	public void mouseReleased(MouseEvent e) {
	}
	
	// randomly chooses amount of lives lost and updates lives left
    public void handleLives() {
    	
    	Random random = new Random();
    	livesLost = random.nextInt(3);
    	livesLeft = livesLeft - livesLost;
    }
    
    // print the scenario on the screen and updates number of lives 
    public String printScenario() {
    	String [][] scenarioChoices = createScenario();
    	
    	if (livesLost == 0) return scenarioChoices[2 * questionNumber - 2][optionIndex];
    	
        else {
    	    numberOfLives.setText("  " + livesLeft + " lives left...");
            return scenarioChoices[2 * questionNumber - 1][optionIndex];
    	}
    }
    // adding action listeners for the option buttons
    public void addNextActionListener(ActionListener listener) {
        optionA.addActionListener(listener);
        optionB.addActionListener(listener);
        optionC.addActionListener(listener);
    }
    
    // performs action once buttons are clicked 
    public void clickAction(){
    	questionText.setText(Qarr[questionNumber]);
    	optionA.setText(optionArr[questionNumber][0]);
    	optionB.setText(optionArr[questionNumber][1]);
    	optionC.setText(optionArr[questionNumber][2]);
    	
    	scenarios.setText(printScenario());
    	questionNumber += 1;
    	questionNumberLabel.setText("Question" + questionNumber);
    	
    }
}
